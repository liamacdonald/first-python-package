
def print_text():
    print('This is version 1.0.2')