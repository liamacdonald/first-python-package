
def print_text():
    print('This is version 0.0.1')